/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.DAO;

import com.Model.Commande;
import com.Model.CommandeId;
import java.util.Calendar;
import java.util.Date;

/**
 *
 * @author DjazzJah
 */
public class NewMain {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {      
        ServicesDAO dao = new ServicesImpl();
          System.out.print(dao.ListAllProduit());
    }
}
