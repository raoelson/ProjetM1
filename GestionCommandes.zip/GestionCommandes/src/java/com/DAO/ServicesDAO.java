/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.DAO;

import com.Model.Client;
import com.Model.Commande;
import com.Model.CommandeId;
import com.Model.Produit;
import com.Model.User;
import java.util.Date;
import java.util.List;

/**
 *
 * @author DjazzJah
 */
public interface ServicesDAO {

    List<Client> getListAll();

    void createClient(Client client);

    void deleteClient(String id);

    void updateClient(Client client);

    String test_client(String id);

    List<Produit> ListAllProduit();

    void createProduit(Produit produit);

    void deleteProduit(String id);

    void updateProduit(Produit produit);

    String test_produit(String id);

    List<User> ListAllUser();

    void createUser(User user);

    void deleteUser(String id);

    void updateUser(User user);

    List<Commande> ListAllCommandes();

    List<Commande> ListAllSearch(Date debut, Date fin);

    void createCommande(Commande cm);

    void deleteCommande(CommandeId id);

    void updateCommande(Commande cm);
}
