/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.DAO;

import com.Model.Client;
import com.Model.Commande;
import com.Model.CommandeId;
import com.Model.Produit;
import com.Model.User;
import com.Outil.HibernateUtil;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.criterion.Restrictions;

/**
 *
 * @author DjazzJah
 */
public class ServicesImpl implements ServicesDAO {

    @Override
    public List<Client> getListAll() {
        SessionFactory sf = HibernateUtil.getSessionFactory();
        Session session = sf.openSession();
        Transaction tr = null;
        List<Client> clients = new ArrayList<Client>();
        try {
            tr = session.beginTransaction();
            Query query = session.createQuery("from Client c order by c.numclient ASC");
            clients = query.list();
            session.flush();
            tr.commit();
        } catch (Exception e) {
            if (tr != null) {
                tr.rollback();
            }
        } finally {
            session.close();
        }
        sf.close();
        return clients;

    }

    @Override
    public void createClient(Client client) {
        SessionFactory sf = HibernateUtil.getSessionFactory();
        Session session = sf.openSession();
        Transaction tr = null;
        try {
            tr = session.beginTransaction();
            session.save(client);
            session.flush();
            tr.commit();
        } catch (Exception e) {
            if (tr != null) {
                tr.rollback();
            }
        } finally {
            session.close();
        }
        sf.close();
    }

    @Override
    public void deleteClient(String id) {
        SessionFactory sf = HibernateUtil.getSessionFactory();
        Session session = sf.openSession();
        Transaction tr = null;
        try {
            tr = session.beginTransaction();
            Client client = (Client) session.get(Client.class, id);
            session.delete(client);
            session.flush();
            tr.commit();
        } catch (Exception e) {
            if (tr != null) {
                tr.rollback();
            }
        } finally {
            session.close();
        }
        sf.close();
    }

    @Override
    public void updateClient(Client client) {
        SessionFactory sf = HibernateUtil.getSessionFactory();
        Session session = sf.openSession();
        Transaction tr = null;
        try {
            tr = session.beginTransaction();
            Client client_ = (Client) session.get(Client.class, client.getNumclient());
            client_.setNomclient(client.getNomclient());
            session.update(client_);
            session.flush();
            tr.commit();
        } catch (Exception e) {
            if (tr != null) {
                tr.rollback();
            }
        } finally {
            session.close();
        }
        sf.close();
    }

    @Override
    public String test_client(String id) {
        String rep = "not";
        SessionFactory sf = HibernateUtil.getSessionFactory();
        Session session = sf.openSession();
        Transaction tr = null;
        try {
            tr = session.beginTransaction();
            Client client = (Client) session.get(Client.class, id);
            if (!client.equals("")) {
                rep = "yes";
            }
            session.flush();
            tr.commit();
        } catch (Exception e) {
            if (tr != null) {
                tr.rollback();
            }
        } finally {
            session.close();
        }
        sf.close();
        return rep;
    }

    @Override
    public List<Produit> ListAllProduit() {
        //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        SessionFactory sf = HibernateUtil.getSessionFactory();
        org.hibernate.Session session = sf.openSession();
        Transaction tr = null;
        List<Produit> produits = new ArrayList<Produit>();
        try {
            tr = session.beginTransaction();
            Query query = session.createQuery("from Produit p order by p.numproduit asc");
            produits = query.list();
            session.flush();
            tr.commit();
        } catch (Exception e) {
            if (tr != null) {
                tr.rollback();
            }
        } finally {
            session.close();
        }
        sf.close();
        return produits;
    }

    @Override
    public void createProduit(Produit produit) {
        SessionFactory sf = HibernateUtil.getSessionFactory();
        org.hibernate.Session session = sf.openSession();
        Transaction tr = null;

        try {
            tr = session.beginTransaction();
            session.save(produit);
            session.flush();
            tr.commit();
        } catch (Exception e) {
            if (tr != null) {
                tr.rollback();
            }
        } finally {
            session.close();
        }
        sf.close();
    }

    @Override
    public void deleteProduit(String id) {
        SessionFactory sf = HibernateUtil.getSessionFactory();
        org.hibernate.Session session = sf.openSession();
        Transaction tr = null;

        try {
            tr = session.beginTransaction();
            Produit p = (Produit) session.get(Produit.class, id);
            session.delete(p);
            session.flush();
            tr.commit();
        } catch (Exception e) {
            if (tr != null) {
                tr.rollback();
            }
        } finally {
            session.close();
        }
        sf.close();
    }

    @Override
    public void updateProduit(Produit produit) {
        SessionFactory sf = HibernateUtil.getSessionFactory();
        org.hibernate.Session session = sf.openSession();
        Transaction tr = null;

        try {
            tr = session.beginTransaction();
            Produit pd = (Produit) session.get(Produit.class, produit.getNumproduit());
            pd.setDesignproduit(produit.getDesignproduit());
            pd.setPuproduit(produit.getPuproduit());
            session.update(pd);
            session.flush();
            tr.commit();
        } catch (Exception e) {
            if (tr != null) {
                tr.rollback();
            }
        } finally {
            session.close();
        }
        sf.close();
    }

    @Override
    public String test_produit(String id) {
        String rep = "not";
        SessionFactory sf = HibernateUtil.getSessionFactory();
        org.hibernate.Session session = sf.openSession();
        Transaction tr = null;
        try {
            tr = session.beginTransaction();
            Produit produit = (Produit) session.get(Produit.class, id);
            if (!produit.equals("")) {
                rep = "yes";
            }
            session.flush();
            tr.commit();
        } catch (Exception e) {
            if (tr != null) {
                tr.rollback();
            }
        } finally {
            session.close();
        }
        sf.close();
        return rep;
    }

    @Override
    public void createUser(User user) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void deleteUser(String id) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void updateUser(User user) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public List<User> ListAllUser() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public List<Commande> ListAllCommandes() {

        SessionFactory sf = HibernateUtil.getSessionFactory();
        Session session = sf.openSession();
        Transaction tr = null;
        Criteria query;
        List<Commande> commande = new ArrayList<Commande>();
        try {
            tr = session.beginTransaction();
            query = session.createCriteria(Commande.class);
            commande = query.list();
            session.flush();
            tr.commit();
        } catch (Exception e) {
            if (tr != null) {
                tr.rollback();
            }
        } finally {
            session.close();
        }
        sf.close();

        return commande;
    }

    @Override
    public void createCommande(Commande cm) {
        SessionFactory sf = HibernateUtil.getSessionFactory();
        org.hibernate.Session session = sf.openSession();
        Transaction tr = null;        
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        String dt = sdf.format(cm.getDatecommande()).toString();
        String annee = dt.substring(0, 4);
        Commande com = new Commande();
        CommandeId id = new CommandeId(cm.getId().getNumclient(), cm.getId().getNumproduit());
        com.setId(id);
        com.setDatecommande(cm.getDatecommande());
        com.setQtecommande(cm.getQtecommande());
        com.setAnnee(annee);
        try {
            tr = session.beginTransaction();
            session.save(com);
            session.flush();
            tr.commit();
        } catch (Exception e) {
            if (tr != null) {
                tr.rollback();
            }
        } finally {
            session.close();
        }
        sf.close();
    }

    @Override
    public void deleteCommande(CommandeId id) {        
        SessionFactory sf = HibernateUtil.getSessionFactory();
        org.hibernate.Session session = sf.openSession();
        Transaction tr = null;

        try {
            tr = session.beginTransaction();
            Commande p = (Commande) session.get(Commande.class, id);
            session.delete(p);
            session.flush();
            tr.commit();
        } catch (Exception e) {
            if (tr != null) {
                tr.rollback();
            }
        } finally {
            session.close();
        }
        sf.close();
    }

    @Override
    public void updateCommande(Commande cm) {
        SessionFactory sf = HibernateUtil.getSessionFactory();
        org.hibernate.Session session = sf.openSession();
        Transaction tr = null;
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        String dt = sdf.format(cm.getDatecommande()).toString();
        String annee = dt.substring(0, 4);
        try {
            tr = session.beginTransaction();
            CommandeId id = new CommandeId(cm.getId().getNumclient(), cm.getId().getNumproduit());
            Commande cm_ = new Commande();
            cm_.setId(id);
            cm_.setQtecommande((cm.getQtecommande()));
            cm_.setDatecommande(cm.getDatecommande());
            cm_.setAnnee(annee);
            session.update(cm_);
            session.flush();
            tr.commit();
        } catch (Exception e) {
            if (tr != null) {
                tr.rollback();
            }
        } finally {
            session.close();
        }
        sf.close();
    }

    @Override
    public List<Commande> ListAllSearch(Date debut, Date fin) {

        SessionFactory sf = HibernateUtil.getSessionFactory();
        Session session = sf.openSession();
        Transaction tr = null;
        Criteria query;
        List<Commande> commande = new ArrayList<Commande>();
        try {
            tr = session.beginTransaction();
            query = session.createCriteria(Commande.class)
                    .add(Restrictions.between("datecommande", debut, fin));
            commande = query.list();
            session.flush();
            tr.commit();
        } catch (Exception e) {
            if (tr != null) {
                tr.rollback();
            }
        } finally {
            session.close();
        }
        sf.close();
        return commande;
    }
}
